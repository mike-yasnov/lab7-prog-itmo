create function handle_event_effects() returns trigger
    language plpgsql
as
$$
DECLARE
    outcome VARCHAR(10);  
BEGIN
    -- Обработка события типа "Battle"
    IF NEW.Type = 'Battle' THEN
        IF RANDOM() < 0.5 THEN
            outcome := 'Victory';
        ELSE
            outcome := 'Defeat';
        END IF;
        
        IF outcome = 'Victory' THEN
            -- Преследователь празднует победу
            UPDATE Stalker 
            SET Injury = FALSE, Abilities = array_append(Abilities, 'Leadership') 
            WHERE ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID);
            
            -- Локация становится безопасной
            UPDATE Location 
            SET Name = CONCAT(Name, ' (Victorious)') 
            WHERE ID = (SELECT Location_ID FROM EventLocation WHERE Event_ID = NEW.ID);

        ELSE  -- Обработка "Defeat" (Поражение)
            -- Преследователь получает ранения
            UPDATE Stalker 
            SET Injury = TRUE 
            WHERE ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID);
            
            -- Локация становится опасной
            UPDATE Location 
            SET Name = CONCAT(Name, ' (Dangerous)') 
            WHERE ID = (SELECT Location_ID FROM EventLocation WHERE Event_ID = NEW.ID);
        END IF;
    END IF;

    -- Обработка события типа "Healing"
    IF NEW.Type = 'Healing' THEN
        -- Преследователь исцелен
        UPDATE Stalker 
        SET Injury = FALSE 
        WHERE ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID);
    END IF;

    -- Обработка события типа "Alliance"
    IF NEW.Type = 'Alliance' THEN
        -- Союзники становятся активными
        UPDATE Ally 
        SET Relationship = 'Active' 
        WHERE ID IN (SELECT Ally_ID FROM StalkerAlly 
                     WHERE Stalker_ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID));
    END IF;

    -- Обработка события типа "Escape"
    IF NEW.Type = 'Escape' THEN
        -- Преследователь успешно убегает
        UPDATE Stalker 
        SET Injury = FALSE 
        WHERE ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID);
        
        -- Союзники сбежали
        UPDATE Ally 
        SET Relationship = 'Escaped' 
        WHERE ID IN (SELECT Ally_ID FROM StalkerAlly 
                     WHERE Stalker_ID = (SELECT Stalker_ID FROM EventStalker WHERE Event_ID = NEW.ID));
        
        -- Локация становится безопасной
        UPDATE Location 
        SET Name = CONCAT(Name, ' (Safe)') 
        WHERE ID IN (SELECT Location_ID FROM EventLocation WHERE Event_ID = NEW.ID);
    END IF;

    -- Обработка события типа "Destruction"
    IF NEW.Type = 'Destruction' THEN
        -- Локация разрушена
        UPDATE Location 
        SET Name = CONCAT(Name, ' (Destroyed)') 
        WHERE ID IN (SELECT Location_ID FROM EventLocation WHERE Event_ID = NEW.ID);
    END IF;

    RETURN NEW;
END;
$$;

alter function handle_event_effects() owner to s413122;

